Circle Game:
-----------------------------------------------------------
Gemacht von Julian Thilo und Tim Kausemann
-----------------------------------------------------------
Anmerkungen:
Wir entschuldigen uns, dafür dass nicht sehr viele Kommentare vorhanden sind,da ich(Tim) meine rechte Hand gebrochen habe und somit meine Schreibgeschwindigkeit verringert war
und ich mich auf das Programieren konzentrieren wollte.
Falls sie Fragen zu dem Code haben bitte kontaktiren sie uns.
-----------------------------------------------------------
Bekannte Bugs:
Manchmal passiert ein Processing interner Fehler, weswegen in den SaveFiles(saveFile.txt)keine Zahlen mehr stehen.Dies führt dann zu einem fehler. 
Um diesen Fhler zu beheben müssen einfach nur 3 Zahlen in saveFile.txt untereinander geschrieben werden. Bsp:

100
49
32

Dabei steht die erste Zahl für die Anzahl der Tode, die zweite für den Highscore und die dritte für die Angriffs wellen die mann überstanden hat (Level Complete = LC)
--------
Außerdem gibt es bei der Pac-Man Attacke(at4) das problem, dass wenn man die attacke berührt nicht sofort stirbt sondern verzögert.
-----------------------------------------------------------
VG 

Julian und Tim
